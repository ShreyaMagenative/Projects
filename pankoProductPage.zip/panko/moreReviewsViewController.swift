import UIKit

class moreReviewsViewController: UIViewController {
    
    let reviewsTextView = UITextView()
    let reviewInputField = UITextField()
    let submitButton = UIButton(type: .system)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup the UI here
        view.backgroundColor = .white
        title = "More Reviews"
        
        setupUI()
    }
    
    func setupUI() {
        // Reviews TextView for displaying existing reviews
        reviewsTextView.text = "Here are more reviews for the product.\n\n- Great product!\n- Really loved it!"
        reviewsTextView.isEditable = false
        reviewsTextView.font = .systemFont(ofSize: 16)
        reviewsTextView.translatesAutoresizingMaskIntoConstraints = false
        reviewsTextView.layer.borderColor = UIColor.lightGray.cgColor
        reviewsTextView.layer.borderWidth = 1
        reviewsTextView.layer.cornerRadius = 8
        
        // Input field for new review
        reviewInputField.placeholder = "Write your review here..."
        reviewInputField.borderStyle = .roundedRect
        reviewInputField.translatesAutoresizingMaskIntoConstraints = false
        
        // Submit button
        submitButton.setTitle("Submit", for: .normal)
        submitButton.translatesAutoresizingMaskIntoConstraints = false
        submitButton.addTarget(self, action: #selector(submitReview), for: .touchUpInside)
        
        // Add components to view
        view.addSubview(reviewsTextView)
        view.addSubview(reviewInputField)
        view.addSubview(submitButton)
        
        // Constraints
        NSLayoutConstraint.activate([
            reviewsTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            reviewsTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            reviewsTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            reviewsTextView.heightAnchor.constraint(equalToConstant: 300),
            
            reviewInputField.topAnchor.constraint(equalTo: reviewsTextView.bottomAnchor, constant: 20),
            reviewInputField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            reviewInputField.trailingAnchor.constraint(equalTo: submitButton.leadingAnchor, constant: -10),
            reviewInputField.heightAnchor.constraint(equalToConstant: 40),
            
            submitButton.topAnchor.constraint(equalTo: reviewsTextView.bottomAnchor, constant: 20),
            submitButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            submitButton.widthAnchor.constraint(equalToConstant: 80),
            submitButton.heightAnchor.constraint(equalToConstant: 40)
        ])
    }
    
    @objc func submitReview() {
        guard let reviewText = reviewInputField.text, !reviewText.isEmpty else { return }
        
        // Append new review to existing text
        reviewsTextView.text += "\n- \(reviewText)"
        
        // Clear the input field
        reviewInputField.text = ""
    }
}


