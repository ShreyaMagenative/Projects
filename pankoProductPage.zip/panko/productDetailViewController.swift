import UIKit

class productDetailViewController: UIViewController {

    static let identifier = "productDetailViewController"
    var product: Product? // This will hold the product details

    // UI elements
    private let segmentedControl = UISegmentedControl(items: ["Details", "Description"])
    private let detailLabel = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        title = "Product Details"
        
        setupUI()
        
        // Display initial content (Details section)
        updateContent()
    }
    
    
    private func setupUI() {
        // Setup segmented control
        segmentedControl.selectedSegmentIndex = 0
        segmentedControl.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(segmentedControl)
        
        // Setup detail label
        detailLabel.numberOfLines = 0
        detailLabel.translatesAutoresizingMaskIntoConstraints = false
        detailLabel.font = UIFont.systemFont(ofSize: 16)
        view.addSubview(detailLabel)
        
        // Add constraints for layout
        NSLayoutConstraint.activate([
            segmentedControl.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            segmentedControl.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            segmentedControl.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            detailLabel.topAnchor.constraint(equalTo: segmentedControl.bottomAnchor, constant: 20),
            detailLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            detailLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }
    
    @objc private func segmentChanged() {
        updateContent()
    }
    
    private func updateContent() {
        guard let product = product else {
            detailLabel.text = "Product details not available."
            return
        }
        
        let displayText: String
        if segmentedControl.selectedSegmentIndex == 0 {
            // Display "Details" content (short description)
            displayText = product.shortDescription.joined(separator: "\n")
        } else {
            // Display "Description" content (full description)
            displayText = product.description.joined(separator: "\n")
        }
        
        // Parse HTML and set as attributed text
        if let htmlData = displayText.data(using: .utf8) {
            let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
                .documentType: NSAttributedString.DocumentType.html,
                .characterEncoding: String.Encoding.utf8.rawValue
            ]
            if let attributedString = try? NSAttributedString(data: htmlData, options: options, documentAttributes: nil) {
                detailLabel.attributedText = attributedString
            } else {
                detailLabel.text = "Failed to load content."
            }
        } else {
            detailLabel.text = "Content not available."
        }
    }
    func configureWithCell(_ cell: UITableViewCell) {
        // Configure the view with the cell (e.g., add it as a subview or extract data)
        view.addSubview(cell)
        
        // Set constraints if needed
        cell.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            cell.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
            cell.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            cell.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            cell.heightAnchor.constraint(equalToConstant: 50),
            cell.widthAnchor.constraint(equalToConstant: 80)
        ])
    }
    
}
