import UIKit

// MARK: - Models
struct ApiResponse: Codable {
    let data: Product
}

struct Product: Codable {
    let productId: [String]
    let productName: [String]
    let productUrl: [String]
    let description: [String]
    let shortDescription: [String]
    let type: [String]
    let stock: [String]
    let price: [PriceWrapper]
    let currencySymbol: String
    let status: String
    let mainProdImg: String
    let productImage: [ProductImage]
    let reviewCount: Int
    let inWishlist: [String]
    
    enum CodingKeys: String, CodingKey {
        case productId = "product-id"
        case productName = "product-name"
        case productUrl = "product-url"
        case description
        case shortDescription = "short-description"
        case type
        case stock
        case price
        case currencySymbol = "currency_symbol"
        case status
        case mainProdImg = "main-prod-img"
        case productImage = "product-image"
        case reviewCount = "review_count"
        case inWishlist = "Inwishlist"
    }
}

struct PriceWrapper: Codable {
    let specialPrice: [Double?]
    let regularPrice: [Double]
    
    enum CodingKeys: String, CodingKey {
        case specialPrice = "special_price"
        case regularPrice = "regular_price"
    }
}

struct ProductImage: Codable {
    let mediaType: String
    let url: String
    let position: String
    
    enum CodingKeys: String, CodingKey {
        case mediaType = "media_type"
        case url
        case position
    }
}

struct ErrorResponse: Codable {
    let message: String
    let success: Bool
}

// MARK: - ViewController
class ViewController: UIViewController,ProductQuantityDescriptionCellDelegate {
    
    var data: [Product] = [] // Data property at the class level
    let tableView = UITableView()
  
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Product Details"
        navigationController?.navigationBar.tintColor = .black
        
        let logoImageView = UIImageView(image: UIImage(named: "logo"))
        logoImageView.contentMode = .scaleAspectFit
        navigationItem.titleView = logoImageView
        
        setupTableView()
        fetchData()
    }
    func didAddItemToCart() {
            let alert = UIAlertController(title: "Item Added", message: "You added Panko to your shopping cart", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    
    func setupTableView() {
        // Register custom cells
        tableView.register(ProductCell.self, forCellReuseIdentifier: "ProductCell")
        tableView.register(ProductQuantityDescriptionCell.self, forCellReuseIdentifier: "ProductQuantityDescriptionCell")
        tableView.register(ProductDetailCell.self, forCellReuseIdentifier: "ProductDetailCell")
        tableView.register(MoreReviewsCell.self, forCellReuseIdentifier: "MoreReviewsCell")
        tableView.register(HeaderCell.self, forCellReuseIdentifier: "HeaderCell")

        // Setup table view properties
        tableView.dataSource = self
        tableView.delegate = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        
        // Setup footer view for table
        let footerView = FooterCell()
        footerView.translatesAutoresizingMaskIntoConstraints = false
        tableView.tableFooterView = footerView
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        footerView.topAnchor.constraint(equalTo: tableView.bottomAnchor).isActive = true
        footerView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        footerView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        footerView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
    }
    

    
    func fetchData() {
        guard let url = URL(string: "https://summitwebstore.com/rest/V1/mobiconnect/catalog/view/") else {
            print("Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        struct Parameters: Encodable {
            let currency_code: String
            let store_id: Int
            let prodID: Int
        }
        
        struct Message: Encodable {
            let parameters: Parameters
        }
        
        let parameters = Parameters(currency_code: "AED", store_id: 1, prodID: 2078)
        let message = Message(parameters: parameters)
        
        do {
            let data = try JSONEncoder().encode(message)
            request.httpBody = data
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                    return
                }
                
                guard let statusCode = (response as? HTTPURLResponse)?.statusCode else {
                    print("No response received")
                    return
                }
                
                if statusCode == 200 {
                    print("Success")
                    if let data = data {
                        do {
                            let apiResponse = try JSONDecoder().decode([ApiResponse].self, from: data)
                            let products = apiResponse.map { $0.data }
                            self.data = products
                            DispatchQueue.main.async {
                                self.tableView.reloadData()
                            }
                        } catch {
                            print("Error decoding product response: \(error.localizedDescription)")
                        }
                    }
                } else {
                    if let data = data {
                        do {
                            let errorResponse = try JSONDecoder().decode([ErrorResponse].self, from: data)
                            print("Error message: \(errorResponse.first?.message ?? "No message")")
                        } catch {
                            print("Error decoding error response: \(error.localizedDescription)")
                        }
                    }
                }
            }
            task.resume()
        } catch {
            print("Error encoding message: \(error.localizedDescription)")
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4 // Four sections: Product, Quantity/Description, Details, Reviews
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return data.count // Number of product cells
        case 1:
            return 1 // One for quantity/description cell
        case 2:
            return 1 // One for detail cell
        case 3:
            return 1// One for more reviews cell
        case 4:
            return 1
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductCell
            let product = data[indexPath.row]
            cell.configure(with: product)
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductQuantityDescriptionCell", for: indexPath) as! ProductQuantityDescriptionCell
            cell.configure(with: data.first) // Ensure data.first is non-nil
            cell.delegate = self
            cell.quantity = 0
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductDetailCell", for: indexPath) as! ProductDetailCell
            cell.configure(with: "Details") // Add appropriate details here
            return cell
        case 3:
            let cell = tableView.dequeueReusableCell(withIdentifier: "MoreReviewsCell", for: indexPath) as! MoreReviewsCell
            cell.configure(with: "More reviews")
            return cell
             case 4:
             let cell = tableView.dequeueReusableCell(withIdentifier: "FooterCell", for: indexPath) as! HeaderCell
             return cell
        default:
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            return 400 // Adjust height as necessary for the ProductCell
        case 1:
            return 250 // Height for quantity/description cell
        case 2:
            return UITableView.automaticDimension // Automatic height for detail cell
        case 3:
            return  UITableView.automaticDimension // Height for more reviews cell
        case 4:
            return 10
        default:
            return 10
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true) // Deselect the row

        switch indexPath.section {
        case 2: // Product Details Cell
//            if let productDetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailViewController") as? productDetailViewController {
//                self.navigationController?.pushViewController(productDetailViewController, animated: true)
//            } else {
//                print("ProductDetailViewController could not be instantiated.")
//            }
            
        
                   
                   
            let vc1 = productDetailViewController()
            vc1.product = self.data.first
            
            navigationController?.pushViewController(vc1, animated: true)
            
            
        case 3: // More Reviews Cell
//            if let moreReviewsViewController = self.storyboard?.instantiateViewController(withIdentifier: "MoreReviewsViewController") as? moreReviewsViewController {
//                self.navigationController?.pushViewController(moreReviewsViewController, animated: true)
//            } else {
//                print("MoreReviewsViewController could not be instantiated.")
//            }
            let vc2 = moreReviewsViewController()
            navigationController?.pushViewController(vc2, animated: true)
            
        default:
            break
        }
    }
        }

// MARK: - Custom UITableViewCell for Product Image and Info

class ProductCell: UITableViewCell {
    
    let productImageView = UIImageView()
    let productNameLabel = UILabel()
    let productPriceLabel = UILabel()
    let currencySymbolLabel = UILabel()
    let wishlistButton = UIButton(type: .system)

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupViews() {
        productImageView.contentMode = .scaleAspectFit
        productNameLabel.font = UIFont.boldSystemFont(ofSize: 16)
        productPriceLabel.font = UIFont.systemFont(ofSize: 14)
        currencySymbolLabel.font = UIFont.systemFont(ofSize: 14)

        wishlistButton.setImage(UIImage(systemName: "heart"), for: .normal)
        wishlistButton.tintColor = .red
        

        contentView.addSubview(productImageView)
        contentView.addSubview(productNameLabel)
        contentView.addSubview(productPriceLabel)
        contentView.addSubview(currencySymbolLabel)
        contentView.addSubview(wishlistButton)
    }

    func setupConstraints() {
        productImageView.translatesAutoresizingMaskIntoConstraints = false
        productNameLabel.translatesAutoresizingMaskIntoConstraints = false
        productPriceLabel.translatesAutoresizingMaskIntoConstraints = false
        currencySymbolLabel.translatesAutoresizingMaskIntoConstraints = false
        wishlistButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            productImageView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            productImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            productImageView.widthAnchor.constraint(equalToConstant: 300),
            productImageView.heightAnchor.constraint(equalToConstant: 300),
            
            productNameLabel.topAnchor.constraint(equalTo: productImageView.bottomAnchor, constant: 10),
            productNameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            productNameLabel.trailingAnchor.constraint(equalTo: wishlistButton.leadingAnchor, constant: -10),
            
            wishlistButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
            wishlistButton.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            wishlistButton.widthAnchor.constraint(equalToConstant: 40),
            wishlistButton.heightAnchor.constraint(equalToConstant: 500),
            
            currencySymbolLabel.topAnchor.constraint(equalTo: productNameLabel.bottomAnchor, constant: 5),
            currencySymbolLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            currencySymbolLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
            
            productPriceLabel.topAnchor.constraint(equalTo: productNameLabel.bottomAnchor, constant: 5),
            productPriceLabel.leadingAnchor.constraint(equalTo: currencySymbolLabel.leadingAnchor, constant: 30),
            productPriceLabel.trailingAnchor.constraint(equalTo: currencySymbolLabel.trailingAnchor, constant: -10),
            productPriceLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10)
        ])
    }
    
    func configure(with product: Product) {
        productNameLabel.text = product.productName.first ?? "N/A"
        if let firstPrice = product.price.first {
            productPriceLabel.text = String(format: "%.0f", firstPrice.regularPrice.first ?? 0.0)
            currencySymbolLabel.text = product.currencySymbol
        }
        
        // Load the image asynchronously
        productImageView.image = nil // Clear previous image
        if let url = URL(string: product.mainProdImg) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                guard let data = data, error == nil else {
                    print("Failed to load image: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                DispatchQueue.main.async {
                    self.productImageView.image = UIImage(data: data)
                }
            }.resume()
        }
    }
}

// MARK: - Custom UITableViewCell for Product Quantity and Description
import UIKit

protocol ProductQuantityDescriptionCellDelegate: AnyObject {
    func didAddItemToCart()
}

class ProductQuantityDescriptionCell: UITableViewCell {

    let quantityLabel = UILabel()
    let shortDescription = UILabel()
    let addButton = UIButton(type: .system)
    let removeButton = UIButton(type: .system)
    let quantityTextField = UITextField()
    let buttonStackView = UIStackView()
    
    weak var delegate: ProductQuantityDescriptionCellDelegate?

    var quantity: Int = 0 {
        didSet {
            quantityTextField.text = "\(quantity)"
        }
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setupViews() {
        quantityLabel.font = .boldSystemFont(ofSize: 18)
        quantityLabel.textColor = .black
        quantityLabel.textAlignment = .center

        shortDescription.font = .boldSystemFont(ofSize: 18)
        shortDescription.textColor = .black
        shortDescription.numberOfLines = 0 // Allow for multi-line

        addButton.setImage(UIImage(systemName: "plus.circle"), for: .normal)
        addButton.titleLabel?.font = .boldSystemFont(ofSize: 24)
        addButton.addTarget(self, action: #selector(increaseQuantity), for: .touchUpInside)
        addButton.tintColor = .black

        removeButton.setImage(UIImage(systemName: "minus.circle"), for: .normal)
        removeButton.addTarget(self, action: #selector(decreaseQuantity), for: .touchUpInside)
        removeButton.titleLabel?.font = .boldSystemFont(ofSize: 24)
        removeButton.tintColor = .black

        // Configure quantityTextField
        quantityTextField.textAlignment = .center
        quantityTextField.borderStyle = .roundedRect
        quantityTextField.isUserInteractionEnabled = false // Make it read-only for user
        quantityTextField.font = .systemFont(ofSize: 18)

        contentView.addSubview(quantityLabel)
        contentView.addSubview(shortDescription)

        // Set up the buttonStackView
        buttonStackView.axis = .horizontal
        buttonStackView.alignment = .center
        buttonStackView.distribution = .fillEqually
        buttonStackView.spacing = 10

        // Add buttons and text field to stack view
        buttonStackView.addArrangedSubview(removeButton)
        buttonStackView.addArrangedSubview(quantityTextField)
        buttonStackView.addArrangedSubview(addButton)

        contentView.addSubview(buttonStackView)
    }

    func setupConstraints() {
        quantityLabel.translatesAutoresizingMaskIntoConstraints = false
        shortDescription.translatesAutoresizingMaskIntoConstraints = false
        quantityTextField.translatesAutoresizingMaskIntoConstraints = false
        addButton.translatesAutoresizingMaskIntoConstraints = false
        removeButton.translatesAutoresizingMaskIntoConstraints = false
        buttonStackView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            quantityLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            quantityLabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            quantityLabel.heightAnchor.constraint(equalToConstant: 40),

            buttonStackView.topAnchor.constraint(equalTo: quantityLabel.bottomAnchor, constant:-50),
            buttonStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 5),
            buttonStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -5),

            shortDescription.topAnchor.constraint(equalTo: buttonStackView.bottomAnchor, constant: 5),
            shortDescription.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            shortDescription.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
            shortDescription.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20)
        ])
    }

    @objc func increaseQuantity() {
        quantity += 1
        delegate?.didAddItemToCart() // Notify the delegate to show the alert
    }

    @objc func decreaseQuantity() {
        if quantity > 0 {
            quantity -= 1
        }
    }

    func configure(with product: Product?) {
        guard let product = product else { return }
        quantityLabel.text = "QUANTITY" // Initialize quantity
        quantityTextField.text = "\(quantity)" // Set initial quantity in text field
        
        // Use NSAttributedString to render HTML
        if let htmlData = product.shortDescription.first?.data(using: .utf8) {
            do {
                let attributedString = try NSAttributedString(data: htmlData, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding: String.Encoding.utf8.rawValue], documentAttributes: nil)
                shortDescription.attributedText = attributedString
            } catch {
                print("Error converting HTML to attributed string: \(error.localizedDescription)")
                shortDescription.text = product.shortDescription.first // Fallback to plain text if there's an error
            }
        } else {
            shortDescription.text = product.shortDescription.first // Fallback if data is nil
        }
    }
}

// MARK: - Custom UITableViewCell for Product Details

class ProductDetailCell: UITableViewCell {
    
    let detailLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupViews() {
        detailLabel.numberOfLines = 0
        detailLabel.font = .boldSystemFont(ofSize: 16)
        detailLabel.textAlignment = .left
//        detailLabel.addTarget(self, action: #selector(controllercall),for: .touchUpInside)
        contentView.addSubview(detailLabel)
    }

    func setupConstraints() {
        detailLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            detailLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            detailLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            detailLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            detailLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10)
        ])
    }

    func configure(with details: String) {
        detailLabel.text = details
    }
}
// MARK: - Custom UITableViewCell for More Reviews

class MoreReviewsCell: UITableViewCell {

    let reviewsLabel = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setupViews() {
        // Configure reviewsLabel
        reviewsLabel.font = .boldSystemFont(ofSize: 16)
        reviewsLabel.textColor = .black
        reviewsLabel.textAlignment = .left
        reviewsLabel.isUserInteractionEnabled = true
        contentView.addSubview(reviewsLabel)

        
    }

    func setupConstraints() {
        reviewsLabel.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            reviewsLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            reviewsLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor,constant: 20),
            reviewsLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor,constant: -20),
            reviewsLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor,constant: -70),

        ])
    }
    
    func configure(with text: String) {
        reviewsLabel.text = text
    }
}
class FooterCell: UIView {
    let addToCartButton = UIButton(type: .system)
    let buyNowButton = UIButton(type: .system)
    let buttonStackView = UIStackView()
    let cellview : UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    override init(frame : CGRect) {
        super.init(frame:frame)
        isMultipleTouchEnabled = true
        isUserInteractionEnabled = true
        setupViews()
        setupConstraints()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupViews() {
        addSubview(cellview)
        cellview.addSubview(buttonStackView)
        
        addToCartButton.setTitle("Add to Cart", for: .normal)
        addToCartButton.setTitleColor(.white, for: .normal)
        addToCartButton.backgroundColor = .black
        addToCartButton.layer.cornerRadius = 0
        addToCartButton.addTarget(self, action: #selector(addToCartTapped), for: .touchUpInside)
        
        buyNowButton.setTitle("Buy Now", for: .normal)
        buyNowButton.setTitleColor(.white, for: .normal)
        buyNowButton.backgroundColor = .systemRed
        buyNowButton.layer.cornerRadius = 0
        buyNowButton.addTarget(self, action: #selector(buyNowTapped), for: .touchUpInside)
        
        buttonStackView.axis = .horizontal
        buttonStackView.distribution = .fillEqually
        buttonStackView.spacing = 1
        buttonStackView.addArrangedSubview(addToCartButton)
        buttonStackView.addArrangedSubview(buyNowButton)
    }
    
    func setupConstraints() {
        cellview.translatesAutoresizingMaskIntoConstraints = false
        buttonStackView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            // Constraints for `cellview` to fill `FooterCell`
            cellview.topAnchor.constraint(equalTo: self.topAnchor),
            cellview.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            cellview.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            cellview.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            
            // Constraints for `buttonStackView` inside `cellview`
            buttonStackView.topAnchor.constraint(equalTo: cellview.topAnchor, constant: 10),
            buttonStackView.leadingAnchor.constraint(equalTo: cellview.leadingAnchor),
            buttonStackView.trailingAnchor.constraint(equalTo: cellview.trailingAnchor),
            buttonStackView.heightAnchor.constraint(equalToConstant: 40),
            buttonStackView.bottomAnchor.constraint(equalTo: cellview.bottomAnchor, constant: -10)
        ])
    }
    
    
    @objc func addToCartTapped() {
        // Handle Add to Cart action
        print("Add to Cart tapped")
    }
    
    @objc func buyNowTapped() {
        // Handle Buy Now action
        print("Buy Now tapped")
    }
}


class HeaderApp: UIView {
    
    // Define the Wi-Fi icon and logo image view
        let wifiIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(systemName: "wifi.circle")
        imageView.tintColor = .black
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private let logoImage: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "logo") // Replace "logo" with the actual image name
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupViews()
    }
    
    private func setupViews() {
        addSubview(wifiIcon)
        addSubview(logoImage)
        
        // Constraints for Wi-Fi icon (left-aligned)
        NSLayoutConstraint.activate([
            wifiIcon.leadingAnchor.constraint(equalTo: leadingAnchor, constant:-350),
            wifiIcon.trailingAnchor.constraint(equalTo: trailingAnchor , constant: 5),
            wifiIcon.heightAnchor.constraint(equalToConstant: 24),
            wifiIcon.widthAnchor.constraint(equalToConstant: 24)
        ])
        
        // Constraints for logo (center-aligned)
        NSLayoutConstraint.activate([
            logoImage.centerXAnchor.constraint(equalTo: centerXAnchor),
            logoImage.centerYAnchor.constraint(equalTo: centerYAnchor),
            logoImage.heightAnchor.constraint(equalToConstant: 100),
            logoImage.widthAnchor.constraint(equalToConstant: 100)
        ])
    }
}


class HeaderCell: UITableViewCell {
    
    // Add the header view as a subview of the cell
    private let headerApp = HeaderApp()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupCell()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupCell()
    }
    
    private func setupCell() {
        contentView.addSubview(headerApp)
        headerApp.translatesAutoresizingMaskIntoConstraints = false
        
        // Constraints to make the header view fill the cell
        NSLayoutConstraint.activate([
            headerApp.topAnchor.constraint(equalTo: contentView.topAnchor),
            headerApp.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            headerApp.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            headerApp.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
    }
}
