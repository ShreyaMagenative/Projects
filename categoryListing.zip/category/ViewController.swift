import UIKit
import SwiftyJSON

// Define a simple struct for your category
struct SubCategory {
    let id: String
    let name: String
    let imageName: String // Add image name
}

struct Category {
    let id: String
    let name: String
    let subCategories: [SubCategory]
    let imageName: String // Add image name
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // Create a table view
    let tableView = UITableView()
    
    // Array to hold the fetched categories
    var categories: [Category] = []
    
    // Array to keep track of expanded categories
    var expandedCategories: [Bool] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup the table view
        setupTableView()
        
        // Call the API when the view loads
        fetchCategories()
    }
    
    // Function to set up the table view
    func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        view.addSubview(tableView)
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    func fetchCategories() {
        guard let url = URL(string: "https://summitwebstore.com/rest/V1/mobiconnectadvcart/category/getallcategories") else {
            print("Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let parameters: [String: Any] = ["parameters": ["store_id": "1", "currency_code": "AED"]]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        } catch {
            print("Error serializing parameters: \(error)")
            return
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching data: \(error)")
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            do {
                let json = try JSON(data: data)
                if json[0]["status"].stringValue == "success" {
                    let categoriesData = json[0]["data"]["categories"].arrayValue
                    self.categories = categoriesData.compactMap { dict in
                        let id = dict["main_category_id"].stringValue
                        let name = dict["main_category_name"].stringValue
                        let imageName = "logo" // Use "logo" for all categories
                        let subCategories = dict["sub_cats"].arrayValue.compactMap { subDict in
                            SubCategory(id: subDict["sub_category_id"].stringValue,
                                        name: subDict["sub_category_name"].stringValue,
                                        imageName: "logo") // Use "logo" for all subcategories
                        }
                        return Category(id: id, name: name, subCategories: subCategories, imageName: imageName)
                    }
                    
                    // Initialize the expandedCategories array
                    self.expandedCategories = Array(repeating: false, count: self.categories.count)
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                } else {
                    print("Status is not success. Response: \(json)")
                }
            } catch let parseError {
                print("Error parsing JSON: \(parseError)")
            }
        }
        
        task.resume()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return categories.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // If the category is expanded, return the number of subcategories, otherwise return 0
        return expandedCategories[section] ? categories[section].subCategories.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let subCategory = categories[indexPath.section].subCategories[indexPath.row]
        
        // Clear previous image views and labels
        cell.contentView.subviews.forEach { $0.removeFromSuperview() }

        let imageView = UIImageView()
        imageView.image = UIImage(named: subCategory.imageName) // Load the logo image
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        cell.contentView.addSubview(imageView)

        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 14)
        label.text = subCategory.name
        label.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(label)

        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor, constant: 8+26),
            imageView.centerYAnchor.constraint(equalTo: cell.contentView.centerYAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 60),
            imageView.heightAnchor.constraint(equalToConstant: 40),

            label.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 8 + 8),
            label.centerYAnchor.constraint(equalTo: cell.contentView.centerYAnchor)
        ])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return categories[section].name
    }

    // Customize the header view to make it tappable
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = .white
        
        let imageView = UIImageView()
        imageView.image = UIImage(named: categories[section].imageName) // Load the logo image
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        headerView.addSubview(imageView)

        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.text = categories[section].name
        label.translatesAutoresizingMaskIntoConstraints = false
        headerView.addSubview(label)

        // Add an image view for the down arrow
        let downArrowImageView = UIImageView()
        downArrowImageView.image = UIImage(systemName: "chevron.down") // Use a system down arrow image
        downArrowImageView.tintColor = .gray // Change the color as needed
        downArrowImageView.translatesAutoresizingMaskIntoConstraints = false
        headerView.addSubview(downArrowImageView)

        headerView.isUserInteractionEnabled = true
        headerView.tag = section // Assign section index to the header
        
        // Add tap gesture recognizer to the header view
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(headerTapped(_:)))
        headerView.addGestureRecognizer(tapGesture)
        
        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 16),
            imageView.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 60),
            imageView.heightAnchor.constraint(equalToConstant: 40),

            label.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 8),
            label.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),

            // Position the down arrow image view
            downArrowImageView.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -16),
            downArrowImageView.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            downArrowImageView.widthAnchor.constraint(equalToConstant: 16),
            downArrowImageView.heightAnchor.constraint(equalToConstant: 16)
        ])

        // Show or hide the down arrow based on the existence of subcategories
        downArrowImageView.isHidden = categories[section].subCategories.isEmpty

        headerView.heightAnchor.constraint(equalToConstant: 44).isActive = true

        return headerView
    }

    @objc func headerTapped(_ sender: UITapGestureRecognizer) {
        guard let headerView = sender.view else { return }
        let section = headerView.tag
        
        // Toggle the expanded state of the section
        expandedCategories[section].toggle()
        
        // Reload the section to reflect the change
        tableView.reloadSections(IndexSet(integer: section), with: .automatic)
    }
}
